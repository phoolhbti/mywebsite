package com.pc.test.cqutil.multipageform;

public class FormField {

	private String name;

	public FormField(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
	
}
