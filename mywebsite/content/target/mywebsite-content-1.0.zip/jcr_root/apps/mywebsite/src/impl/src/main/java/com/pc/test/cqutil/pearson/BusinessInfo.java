package com.pc.test.cqutil.pearson;

public class BusinessInfo{
	
}

